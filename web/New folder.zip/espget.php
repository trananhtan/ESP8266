<?php
require "dbcon.php";
$query ="SELECT * FROM `Room1`";
$data =mysql_query($connect,$query);
while($row =mysql_fetch_assoc($data))
{
    echo $row['ten']; echo"="; echo $row['App']. 'br/>';
    
}
?>