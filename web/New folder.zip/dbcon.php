<?php
 $severname ="NS5000824\MSSQL2016";
 $username="anhtan1002";
 $dbname="anhtan1002_iot";
 $pass="anhtan123";
$connect = mysqli_connect($severnam,$usernam,$pass,$dbname);
mysql_query($connect,"SET NAMES 'utf8'");

?>