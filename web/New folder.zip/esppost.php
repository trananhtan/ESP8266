<?php

require "dbcon.php";
$ten=$POST['ten'];
$new=$POST['new'];
$id =$POST['id'];
$time= new DateTime();
$query ="UPDATE Room1 SET Stt='$id',Ten='$ten',New='$new',Time='$time' WHERE id ='$id'";

if(mysql_connect($connect,$query))
{
    echo "1";
}
else {
echo "0";
}

?>